$(document).ready(function () {
    $("#carousel-header").owlCarousel({
        items: 1,
        nav: true,
        navText: [],
        loop: true
    });
});